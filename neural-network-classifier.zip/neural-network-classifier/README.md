
# Neural Network Classifier for Letters A, B, and C

## 📘 Overview
This project implements a simple **feedforward neural network from scratch** using only NumPy to classify binary images of the letters **A, B, and C**. Each letter is represented as a 5×6 binary pixel grid (flattened to 30 values).

## 🧠 Neural Network Architecture
- **Input Layer**: 30 neurons (5×6 image)
- **Hidden Layer**: 16 neurons, sigmoid activation
- **Output Layer**: 3 neurons (A, B, C), softmax activation

## ⚙️ Features
- Manual binary dataset (no external file required)
- Feedforward pass and backpropagation logic implemented manually
- Cross-entropy loss function
- Training for 5000 epochs with accuracy/loss visualization

## 🧪 Prediction Example
After training, the model predicts letters and visualizes the corresponding binary grid using `matplotlib.pyplot.imshow()`.

## 📊 Visualization
Plots of training **loss** and **accuracy** over time are included to track model performance.

## 🗃️ Files Included
- `neural_network_classifier.ipynb` – Full implementation notebook

## 🚀 How to Run
1. Open the `.ipynb` file in Jupyter Notebook or Google Colab.
2. Run all cells to train the model and visualize results.

---

*This project is a hands-on implementation designed for educational purposes in Module 11 of the AI course curriculum.*
